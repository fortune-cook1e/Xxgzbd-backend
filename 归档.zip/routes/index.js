
const city = require('./city')
const total = require('./total')
const goods = require("./goods")



module.exports = {
  city:city,
  total:total,
  goods:goods
}