
const success = {
  code:200,
  status:1,
  msg:'success'
}

const failure = {
  code:500,
  status:0,
  msg:"failure"
}


module.exports = {
  success,
  failure
}